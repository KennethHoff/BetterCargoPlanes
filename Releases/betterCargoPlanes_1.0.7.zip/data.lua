require("prototypes.entities")
require("prototypes.equipment-grid")
require("prototypes.items")
require("prototypes.recipes")
require("prototypes.technologies")
require("prototypes.recipe-updates") --Mod Compatibility
require("prototypes.technologies-updates") --Mod Compatibility