data:extend({
    {
        type = "bool-setting",
        name = "betterCargoPlanes-MilitaryEquipment",
        setting_type = "startup",
        default_value = false,
        order="aa",
    }
})