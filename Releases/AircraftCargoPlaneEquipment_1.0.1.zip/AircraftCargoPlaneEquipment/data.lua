require("prototypes.entities")
require("prototypes.equipment-grid")