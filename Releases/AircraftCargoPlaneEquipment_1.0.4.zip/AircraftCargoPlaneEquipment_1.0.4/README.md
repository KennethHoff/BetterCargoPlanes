# AircraftCargoPlaneEquipment
Improves the Cargo Plane from the Aircraft mod to have an Equipment Slot. I always preferred the Cargo Plane, but it felt useless without an Equipment 
