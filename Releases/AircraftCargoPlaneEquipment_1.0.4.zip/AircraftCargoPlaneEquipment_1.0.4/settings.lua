data:extend({
    {
        type = "bool-setting",
        name = "aircraftCargoPlane-equipment-armoured",
        setting_type = "startup",
        default_value = false,
        order="aa",
    }
})